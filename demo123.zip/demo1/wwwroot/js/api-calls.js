﻿document.addEventListener('DOMContentLoaded', () => {
    const userList = document.getElementById('userList');
    fetch('/api/UserApi/GetUsers')
        .then(response => response.json())
        .then(data => {
            data.forEach(user => {
                const listItem = document.createElement('li');
                listItem.className = 'list-group-item';
                listItem.textContent = `Name: ${user.name}, Email: ${user.email}`;
                userList.appendChild(listItem);
            });
        })
        .catch(error => console.error('Error fetching users:', error));
});
