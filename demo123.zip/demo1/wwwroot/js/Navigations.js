﻿// Define API endpoints for each navigation item
const apiEndpoints = {
    home: '/api/home',
    profile: '/api/user/profile',
    policyDetails: '/api/policies',
    claims: '/api/claims',
    billing: '/api/billing',
    documents: '/api/documents', // Future: Add documents API
    notifications: '/api/notifications', // Future: Add notifications API
    support: '/api/support',
    settings: '/api/settings',
    logout: '/api/user/logout'
};

// Function to navigate to the selected section
function navigateTo(section) {
    const contentDiv = document.getElementById('main-content');
    contentDiv.innerHTML = `<p>Loading ${section}...</p>`; // Show a loading message

    // Check if the section exists in apiEndpoints
    if (apiEndpoints[section]) {
        // Fetch data for the selected section
        fetch(apiEndpoints[section])
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Error: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                renderSection(section, data); // Render the fetched data
            })
            .catch(error => {
                contentDiv.innerHTML = `<p class="text-danger">Failed to load ${section}. Error: ${error.message}</p>`;
            });
    } else {
        contentDiv.innerHTML = `<p class="text-danger">Section "${section}" not found.</p>`;
    }
}

// Function to render the content for a specific section
function renderSection(section, data) {
    const contentDiv = document.getElementById('main-content');
    contentDiv.innerHTML = ''; // Clear previous content

    // Add section title
    const title = document.createElement('h2');
    title.textContent = section.charAt(0).toUpperCase() + section.slice(1);
    contentDiv.appendChild(title);

    // Add content dynamically based on section
    switch (section) {
        case 'home':
            contentDiv.innerHTML += `
                <div>
                    <p><strong>Claims in Progress:</strong> ${data.claimsInProgress}</p>
                    <p><strong>Active Policies:</strong> ${data.activePolicies}</p>
                    <p><strong>Overdue Payments:</strong> ${data.overduePayments}</p>
                </div>
            `;
            break;

        case 'profile':
            contentDiv.innerHTML += `
                <div>
                    <p><strong>Name:</strong> ${data.name}</p>
                    <p><strong>Email:</strong> ${data.email}</p>
                    <p><strong>Phone:</strong> ${data.phone}</p>
                </div>
            `;
            break;

        case 'policyDetails':
            contentDiv.innerHTML += renderTable(data, ['Policy Name', 'Coverage Amount', 'Premium', 'Effective Date', 'Expiry Date']);
            break;

        case 'claims':
            contentDiv.innerHTML += renderTable(data, ['Claim ID', 'Policy ID', 'Claim Amount', 'Claim Status', 'Filed Date']);
            break;

        case 'billing':
            contentDiv.innerHTML += renderTable(data, ['Payment ID', 'Policy ID', 'Amount', 'Payment Date', 'Status']);
            break;

        default:
            contentDiv.innerHTML = `<p>No specific renderer for "${section}". Data: <pre>${JSON.stringify(data, null, 2)}</pre></p>`;
            break;
    }
}

// Utility function to render a table
function renderTable(data, columns) {
    if (!Array.isArray(data) || data.length === 0) {
        return `<p>No data available.</p>`;
    }

    let table = '<table class="table table-striped">';
    table += '<thead><tr>';
    columns.forEach(col => {
        table += `<th>${col}</th>`;
    });
    table += '</tr></thead>';
    table += '<tbody>';
    data.forEach(row => {
        table += '<tr>';
        columns.forEach(col => {
            const key = col.toLowerCase().replace(/ /g, ''); // Convert column name to object key
            table += `<td>${row[key] || '-'}</td>`;
        });
        table += '</tr>';
    });
    table += '</tbody></table>';
    return table;
}

// Function to handle logout
function handleLogout() {
    fetch(apiEndpoints.logout, { method: 'POST' })
        .then(response => {
            if (response.ok) {
                window.location.href = '/User/UserLogin'; // Redirect to login page
            } else {
                throw new Error('Logout failed.');
            }
        })
        .catch(error => {
            alert(`Error: ${error.message}`);
        });
}

// Attach event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Example: Add click event to the logout link
    const logoutLink = document.querySelector('a[href="#logout"]');
    if (logoutLink) {
        logoutLink.addEventListener('click', handleLogout);
    }
});
