﻿using System;

namespace demo1.Models
{
    public class Policy
    {
        public int Id { get; set; } // Policy ID
        public string Name { get; set; } // Policy Name
        public string Type { get; set; } // Policy Type (e.g., Health, Auto)
        public decimal CoverageAmount { get; set; } // Coverage Amount
        public decimal PremiumAmount { get; set; } // Premium Amount
        public DateTime ExpirationDate { get; set; } // Expiration Date

        // Keeping setters public if external modification is required
        public string PolicyId { get; set; } // Policy identifier for internal use
        public string PolicyName { get; set; } // Name of the Policy
        public int Premium { get; set; } // Premium Amount
    }
}
