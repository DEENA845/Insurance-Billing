﻿namespace demo1.Models
{
    
        public class AdminDashboardData
        {
            public int TotalUsers { get; set; } // Total number of registered users
            public int ActiveClaims { get; set; } // Total number of active claims
            public int PendingPayments { get; set; } // Total number of pending payments
        }
    }


