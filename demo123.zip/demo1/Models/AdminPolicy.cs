﻿namespace demo1.Models
{
    public class AdminPolicy
    {
        public int PolicyId { get; set; }
        public string PolicyName { get; set; } // The name of the policy
        public decimal CoverageAmount { get; set; } // Maximum coverage amount
        public decimal Premium { get; set; } // Monthly premium cost
        public DateTime EffectiveDate { get; set; } // Start date of the policy
        public DateTime ExpiryDate { get; set; } // End date of the policy
    }
}
