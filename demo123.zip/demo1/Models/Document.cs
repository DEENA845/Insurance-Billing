﻿using System;

namespace demo1.Models
{
    public class Document
    {
        public int Id { get; set; } // Document ID
        public string Filename { get; set; } // Name of the File
        public string Type { get; set; } // File Type (e.g., PDF, JPG)
        public DateTime UploadDate { get; set; } // Date of Upload
        public string FilePath { get; set; } // Server Path to the File
    }
}
