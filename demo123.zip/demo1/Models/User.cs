﻿using System.ComponentModel.DataAnnotations;

namespace demo1.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }

        public string Phone { get; set; }
        public string Address { get; set; }
        public string? ProfilePictureUrl { get; set; }
        public DateTime DateOfBirth { get; set; }
        public bool IsProfileComplete { get; set; }
        public bool IsApproved { get; set; }
        public bool IsActive { get; set; }

        [Required]
        public string Gender { get; set; }
    }
}
