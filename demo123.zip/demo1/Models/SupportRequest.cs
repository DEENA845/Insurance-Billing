﻿namespace demo1.Models
{
    public class SupportRequest
    {
        public int Id { get; set; }
        public string UserEmail { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
        public DateTime SubmittedDate { get; set; } = DateTime.Now;
    }
}
