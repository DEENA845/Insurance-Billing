﻿namespace demo1.Models
{
    public class AdminChartData
    {
        public string Label { get; set; } // Label for the chart (e.g., "Approved Claims")
        public int Value { get; set; } // Value corresponding to the label
    }
}
