﻿namespace demo1.Models
{
    public class Payment
    {
        public int PaymentId { get; set; }
        public int PolicyId { get; set; } // Foreign Key for Policy
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }
        public string Status { get; set; } // E.g., Paid, Pending, Failed
    }
}
