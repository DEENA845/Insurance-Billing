﻿using System;

namespace demo1.Models
{
    public class BillingHistory
    {
        public int Id { get; set; } // Payment ID
        public decimal Amount { get; set; } // Amount Paid
        public DateTime Date { get; set; } // Date of Payment
        public string Status { get; set; } // Status (e.g., Paid, Pending, Failed)
    }
}
