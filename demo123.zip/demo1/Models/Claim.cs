﻿using System;

namespace demo1.Models
{
    public class Claim
    {
        // Primary Fields
        public int Id { get; set; } // Claim ID
        public string PolicyName { get; set; } // Associated Policy Name
        public decimal ClaimAmount { get; set; } // Amount Being Claimed
        public string Status { get; set; } // Status (e.g., Pending, Approved, Rejected)
        public DateTime SubmittedDate { get; set; } // Date the Claim was Submitted
        public int PolicyId { get; set; } // Reference to Policy
        public string ClaimType { get; set; } // Type of Claim (e.g., Health, Auto, Property)
        public string ClaimStatus { get; set; } // Current status of the Claim

        // Incident/Event Details
        public DateTime IncidentDate { get; set; } // Date and Time of the Incident
        public string IncidentLocation { get; set; } // Location of the Incident
        public string IncidentDescription { get; set; } // Description of the Incident

        // Supporting Documents
        public string ProofOfIncident { get; set; } // Path or reference to proof documents
        public string ReceiptsOrInvoices { get; set; } // Path or reference to receipts/invoices

        // Witness Information
        public string WitnessName { get; set; } // Witness Name (if applicable)
        public string WitnessContact { get; set; } // Witness Contact (if applicable)

        // Bank Details for Settlement
        public string BankAccountNumber { get; set; } // Bank Account Number for settlement
        public string IFSCCode { get; set; } // IFSC Code of the bank

        // Authentication and Verification
        public string PolicyholderSignature { get; set; } // Signature of the policyholder
        public string IdentityProof { get; set; } // Path or reference to uploaded identity proof

        // Metadata
        public string CreatedBy { get; set; } // User/Admin who created the claim
        public DateTime CreatedDate { get; set; } // Timestamp of claim creation
        public string StatusHistory { get; set; } // Log of previous statuses
    }
}
