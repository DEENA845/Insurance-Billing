﻿namespace demo1.Models
{
    public class PolicyManagementModel
    {
    }
}
