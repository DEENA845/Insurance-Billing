﻿namespace demo1.Models
{
   
        public class AdminUser
        {
            public int UserId { get; set; }
            public string Name { get; set; }
            public string Email { get; set; }
            public bool IsActive { get; set; } // Indicates if the account is active
        }
    }


