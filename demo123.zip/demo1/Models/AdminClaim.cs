﻿namespace demo1.Models
{
    public class AdminClaim
    {
        public int ClaimId { get; set; }
        public int PolicyId { get; set; } // Reference to the associated policy
        public decimal ClaimAmount { get; set; } // The amount requested in the claim
        public string ClaimStatus { get; set; } // Status: Pending, Approved, or Rejected
        public DateTime FiledDate { get; set; } // Date the claim was filed
    }
}
