﻿namespace demo1.Models
{
    public class AIClaimResult
    {
        public bool IsFraudulent { get; set; } // Indicates if the claim is flagged as fraud
        public bool IsValidPolicy { get; set; } // Indicates if the claim matches the policy terms
        public double RiskScore { get; set; } // Risk score of the claim (0.0 to 1.0)
    }
}
