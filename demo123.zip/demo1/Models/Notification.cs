﻿using System;

namespace demo1.Models
{
    public class Notification
    {
        public int Id { get; set; } // Notification ID
        public string Message { get; set; } // Notification Message
        public DateTime DateCreated { get; set; } // Date the Notification was Created
    }
}
