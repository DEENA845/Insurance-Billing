﻿    using Microsoft.EntityFrameworkCore;
    using demo1.Models;

    namespace demo1.Data
    {
        public class AppDbContext : DbContext
        {
            public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
            {
            }

            public DbSet<BillingHistory> BillingHistories { get; set; }
            public DbSet<Claim> Claims { get; set; }
            public DbSet<Document> Documents { get; set; }
            public DbSet<Notification> Notifications { get; set; }
            public DbSet<Policy> Policies { get; set; }
            public DbSet<SupportRequest> SupportRequests { get; set; }
            public DbSet<User> Users { get; set; }
            public DbSet<Payment> Payments { get; set; }

            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {

            modelBuilder.Entity<Policy>()
                .HasIndex(p => p.PolicyId)
                .IsUnique();


            modelBuilder.Entity<BillingHistory>()
                    .Property(b => b.Amount)
                    .HasColumnType("decimal(18,2)");

                modelBuilder.Entity<Claim>()
                    .Property(c => c.ClaimAmount)
                    .HasColumnType("decimal(18,2)");

                modelBuilder.Entity<Payment>()
                    .Property(p => p.Amount)
                    .HasColumnType("decimal(18,2)");

                modelBuilder.Entity<Policy>()
                    .Property(p => p.CoverageAmount)
                    .HasColumnType("decimal(18,2)");

                modelBuilder.Entity<Policy>()
                    .Property(p => p.PremiumAmount)
                    .HasColumnType("decimal(18,2)");
            }
        }
    }
