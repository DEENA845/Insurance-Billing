﻿namespace demo1.AdminServices
{
    public class AdminFraudDetection
    {
    }
}
