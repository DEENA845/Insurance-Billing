﻿using demo1.Models;

namespace demo1.Services
{
    public class AIClaimService
    {
        // Analyze a claim and return an AIClaimResult
        public AIClaimResult AnalyzeClaim(Claim claim)
        {
            // Step 1: Detect fraud using AI logic
            bool isFraudulent = DetectFraud(claim);

            // Step 2: Calculate a risk score for the claim
            double riskScore = CalculateRiskScore(claim);

            // Step 3: Return the AI analysis results
            return new AIClaimResult
            {
                IsFraudulent = isFraudulent,
                RiskScore = riskScore
            };
        }

        // Private helper method to detect fraud
        private bool DetectFraud(Claim claim)
        {
            // Example AI logic for fraud detection
            // You can replace this with machine learning models or advanced rule-based systems
            if (claim.ClaimAmount > 50000 && claim.PolicyName.Contains("High Risk"))
            {
                return true; // Mark as fraudulent for high-risk policies with large amounts
            }

            // Additional conditions for detecting fraud
            if (string.IsNullOrWhiteSpace(claim.PolicyName) || claim.ClaimAmount <= 0)
            {
                return true; // Invalid claims are treated as fraud
            }

            return false; // Otherwise, the claim is not fraudulent
        }

        // Private helper method to calculate risk score
        private double CalculateRiskScore(Claim claim)
        {
            // Example risk scoring logic
            if (claim.ClaimAmount > 100000) return 0.9; // High risk for very large claims
            if (claim.ClaimAmount > 50000) return 0.7; // Medium risk
            if (claim.ClaimAmount > 20000) return 0.5; // Low-medium risk

            return 0.3; // Low risk for smaller claims
        }
    }
}
