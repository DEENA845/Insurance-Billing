﻿using demo1.Models;

namespace demo1.Helpers
{
    public static class UserHelpers
    {
        public static string GetProfilePictureUrl(User user)
        {
            if (user == null || string.IsNullOrEmpty(user.Gender))
            {
                return "/images/default.png"; // Default image if user or gender is null
            }

            if (string.IsNullOrEmpty(user.ProfilePictureUrl))
            {
                return user.Gender.ToLower() == "male" ? "/images/default-male.png" : "/images/default-female.png";
            }
            return user.ProfilePictureUrl;
        }
    }
}
