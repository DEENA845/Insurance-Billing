﻿using Microsoft.AspNetCore.Mvc;
using demo1.Models;
using demo1.Services;
using demo1.Data;
using System.Collections.Generic;
using System.Linq;

namespace demo1.Controllers
{
    [Route("admin")]
    public class AdminController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly AppDbContext _dbContext;
        private readonly AIClaimService _aiClaimService;

        public AdminController(IConfiguration configuration, AppDbContext dbContext, AIClaimService aiClaimService)
        {
            _configuration = configuration;
            _dbContext = dbContext;
            _aiClaimService = aiClaimService;
        }

        // Approve User
        [HttpPost("ApproveUserAction")]
        public IActionResult ApproveUserAction(int userId)
        {
            var user = _dbContext.Users.Find(userId);
            if (user == null) return NotFound("User not found.");

            user.IsApproved = true; // Ensure IsApproved property exists in User model and database
            _dbContext.SaveChanges();

            return Json(new { message = "User approved successfully." });
        }

        // Approve Claim
        [HttpPost("ApproveClaimAction")]
        public IActionResult ApproveClaimAction(int claimId)
        {
            var claim = _dbContext.Claims.Find(claimId);
            if (claim == null) return NotFound("Claim not found.");

            claim.Status = "Approved"; // Ensure Status property exists in Claim model and database
            _dbContext.SaveChanges();

            return Json(new { message = "Claim approved successfully." });
        }

        // Reject Claim
        [HttpPost("RejectClaimAction")]
        public IActionResult RejectClaimAction(int claimId)
        {
            var claim = _dbContext.Claims.Find(claimId);
            if (claim == null) return NotFound("Claim not found.");

            claim.Status = "Rejected";
            _dbContext.SaveChanges();

            return Json(new { message = "Claim rejected successfully." });
        }

        // AI-Based Claim Analysis
        [HttpPost("AnalyzeClaim")]
        public IActionResult AnalyzeClaim(int claimId)
        {
            var claim = _dbContext.Claims.Find(claimId);
            if (claim == null) return NotFound("Claim not found.");

            var analysisResult = _aiClaimService.AnalyzeClaim(claim);

            return Json(analysisResult);
        }

        // Approve User View
        [HttpGet("ApproveUser")]
        public IActionResult ApproveUser()
        {
            var users = _dbContext.Users.Where(u => !u.IsApproved).ToList(); // Filter unapproved users
            return PartialView("_ApproveUser", users);
        }

        // Manage Claims View
        [HttpGet("ManageClaims")]
        public IActionResult ManageClaims()
        {
            var claims = _dbContext.Claims.ToList();
            return PartialView("_ManageClaims", claims);
        }

        // Validate Admin Credentials
        [HttpPost("ValidateAdmin")]
        public IActionResult ValidateAdmin(string username, string password)
        {
            var adminUsername = _configuration["AdminCredentials:AdminUsername"];
            var adminPassword = _configuration["AdminCredentials:AdminPassword"];

            if (username == adminUsername && password == adminPassword)
            {
                return RedirectToAction("Dashboard", "Admin");
            }

            ViewBag.ErrorMessage = "Invalid username or password.";
            return View("AdminLogin");
        }

        // Validate Admin Key
        [HttpPost("ValidateKey")]
        public IActionResult ValidateKey([FromBody] AdminKeyModel model)
        {
            var adminKey = _configuration["AdminCredentials:AdminKey"];
            if (model.AdminKey == adminKey)
            {
                return Json(new { success = true });
            }
            return Json(new { success = false });
        }

        // Dashboard View
        public IActionResult Dashboard()
        {
            var data = GetAdminChartData();
            if (data == null)
            {
                data = new List<AdminChartData>(); // Initialize with an empty list if data is null
            }
            return View(data);
        }

        private IEnumerable<AdminChartData> GetAdminChartData()
        {
            // Replace with actual data fetching logic
            return new List<AdminChartData>
            {
                new AdminChartData { Label = "Approved Claims", Value = 12 },
                new AdminChartData { Label = "Rejected Claims", Value = 5 },
                new AdminChartData { Label = "Pending Claims", Value = 8 }
            };
        }

        // Index View
    }

    // Model for Admin Key Validation
    public class AdminKeyModel
    {
        public string AdminKey { get; set; }
    }
}
