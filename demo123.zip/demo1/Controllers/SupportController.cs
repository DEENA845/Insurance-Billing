﻿using demo1.Models;
using Microsoft.AspNetCore.Mvc;

namespace demo1.Controllers
{
    [ApiController]
    [Route("api/support")]
    public class SupportController : ControllerBase
    {
        // Get support information
        [HttpGet]
        public IActionResult GetSupportInfo()
        {
            var supportInfo = new
            {
                hotline = "+1234567890",
                email = "support@company.com",
                faqLink = "https://company.com/faqs"
            };

            return Ok(supportInfo);
        }

        // Submit a support request
        [HttpPost]
        public IActionResult SubmitSupportRequest([FromBody] SupportRequest request)
        {
            if (request == null || !ModelState.IsValid)
            {
                return BadRequest(new { message = "Invalid support request data." });
            }

            // Simulate saving support request
            return Ok(new { message = "Support request submitted successfully." });
        }
    }
}


