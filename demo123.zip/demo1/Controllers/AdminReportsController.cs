﻿using Microsoft.AspNetCore.Mvc;
using demo1.Models;
using demo1.Data; // Assuming your DbContext is in this namespace
using System.Linq;

namespace demo1.AdminControllers
{
    [Route("admin/reports")]
    public class AdminReportsController : Controller
    {
        private readonly AppDbContext _context;

        public AdminReportsController(AppDbContext context)
        {
            _context = context;
        }

        // Display the reports dashboard
        [HttpGet("dashboard")]
        public IActionResult Dashboard()
        {
            var reportData = new List<AdminChartData>
            {
                new AdminChartData { Label = "Claims Approved", Value = _context.Claims.Count(c => c.Status == "Approved") },
                new AdminChartData { Label = "Claims Rejected", Value = _context.Claims.Count(c => c.Status == "Rejected") },
                new AdminChartData { Label = "Claims Pending", Value = _context.Claims.Count(c => c.Status == "Pending") }
            };

            return View(reportData);
        }

        // Generate user activity report
        [HttpGet("users")]
        public IActionResult UserReports()
        {
            var userActivityData = _context.Users
                .Select(u => new { u.Name, u.Email, u.DateOfBirth })
                .ToList();

            return View(userActivityData);
        }

        // Generate claims report
        [HttpGet("claims")]
        public IActionResult ClaimsReports()
        {
            var claimsData = _context.Claims
                .Select(c => new { c.PolicyName, c.ClaimAmount, c.Status, c.SubmittedDate })
                .ToList();

            return View(claimsData);
        }
    }
}
