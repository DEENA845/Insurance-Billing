using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using demo1.Models;
using System.Net.Http;
using System.Text.Json;

namespace demo1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly HttpClient _httpClient;

        // Constructor initializes logger and HttpClient
        public HomeController(ILogger<HomeController> logger, IHttpClientFactory clientFactory)
        {
            _logger = logger;
            _httpClient = clientFactory.CreateClient();
        }

        // Index action for the default homepage
        public IActionResult Index()
        {
            return View(); // Returns Index.cshtml view
        }

        // Privacy action for the privacy policy page
        public IActionResult Privacy()
        {
            return View(); // Returns Privacy.cshtml view
        }

        // Fetch users from an external API and render them in the view
        public async Task<IActionResult> GetUsers()
        {
            try
            {
                var response = await _httpClient.GetAsync("https://yourapiurl/api/UserApi/GetUsers");

                if (response.IsSuccessStatusCode)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    var users = JsonSerializer.Deserialize<List<User>>(jsonString);

                    return View(users); // Returns GetUsers.cshtml view with the list of users
                }
                else
                {
                    _logger.LogError($"Failed to fetch users. Status Code: {response.StatusCode}");
                    return View("Error"); // Error view if API call fails
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred: {ex.Message}");
                return View("Error"); // Error view for unexpected errors
            }
        }

        // Error action for handling unexpected application errors
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        // Register action for the registration page
        public IActionResult Register()
        {
            return View(); // Returns Register.cshtml view
        }
    }
}

