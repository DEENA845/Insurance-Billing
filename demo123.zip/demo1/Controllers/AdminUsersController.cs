﻿using Microsoft.AspNetCore.Mvc;
using demo1.Models;
using demo1.Data; // Assuming your DbContext is in this namespace
using System.Linq;

namespace demo1.AdminControllers
{
    [Route("admin/users")]
    public class AdminUsersController : Controller
    {
        private readonly AppDbContext _context;

        public AdminUsersController(AppDbContext context)
        {
            _context = context;
        }

        // Display user management view
        [HttpGet("manage")]
        public IActionResult ManageUsers()
        {
            var users = _context.Users.ToList();
            return View(users);
        }

        // Approve a user account
        [HttpPost("approve")]
        public IActionResult ApproveUser(int userId)
        {
            var user = _context.Users.Find(userId);
            if (user == null)
            {
                return NotFound(new { message = "User not found." });
            }

            user.IsApproved = true;
            _context.SaveChanges();

            return Ok(new { message = $"User {userId} approved successfully." });
        }

        // Block a user account
        [HttpPost("block")]
        public IActionResult BlockUser(int userId)
        {
            var user = _context.Users.Find(userId);
            if (user == null)
            {
                return NotFound(new { message = "User not found." });
            }

            user.IsActive = false;
            _context.SaveChanges();

            return Ok(new { message = $"User {userId} blocked successfully." });
        }
    }
}
