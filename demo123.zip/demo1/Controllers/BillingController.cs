﻿using Microsoft.AspNetCore.Mvc;
using demo1.Data;
using demo1.Models;
using System.Linq;
using System.Threading.Tasks;

namespace demo1.Controllers
{
    [ApiController]
    [Route("api/billing")]
    public class BillingController : ControllerBase
    {
        private readonly AppDbContext _context;

        public BillingController(AppDbContext context)
        {
            _context = context;
        }

        // Generate Invoice Number
        [HttpGet("generateInvoiceNumber")]
        public IActionResult GenerateInvoiceNumber()
        {
            string invoicePrefix = "INV";
            string uniqueSuffix = new Random().Next(10000, 99999).ToString();
            string generatedInvoiceNumber = $"{invoicePrefix}-{uniqueSuffix}";

            return Ok(generatedInvoiceNumber);
        }

        // Submit Payment
        [HttpPost("submitPayment")]
        public IActionResult SubmitPayment([FromBody] Payment payment)
        {
            if (payment == null || !ModelState.IsValid)
                return BadRequest(new { message = "Invalid payment data." });

            var policy = _context.Policies.FirstOrDefault(p => p.PolicyId == payment.PolicyId);
            if (policy == null)
                return NotFound(new { message = "Policy ID not found." });

            try
            {
                _context.Payments.Add(payment);
                _context.SaveChanges();

                return Ok(new { message = "Payment processed successfully." });
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while processing the payment.", error = ex.Message });
            }
        }

        // Fetch Payment History for a Specific Policy
        [HttpGet("getPaymentHistory/{policyId}")]
        public IActionResult GetPaymentHistory(int policyId)
        {
            var payments = _context.Payments
                .Where(p => p.PolicyId == policyId)
                .Select(p => new
                {
                    p.InvoiceNumber,
                    p.PolicyId,
                    p.Amount,
                    p.PaymentDate,
                    p.Status,
                    p.PaymentMethod
                })
                .ToList();

            if (!payments.Any())
                return NotFound(new { message = "No payment records found for the given Policy ID." });

            return Ok(payments);
        }

        // Calculate Late Penalties for Overdue Payments
        [HttpGet("calculateLatePenalty/{policyId}")]
        public IActionResult CalculateLatePenalty(int policyId)
        {
            var policy = _context.Policies.FirstOrDefault(p => p.PolicyId == policyId);
            if (policy == null)
                return NotFound(new { message = "Policy ID not found." });

            // Example logic for late penalties (10% penalty for overdue payments)
            var latePenalty = policy.PremiumAmount * 0.1m;

            return Ok(new { LatePenalty = latePenalty });
        }

        // Get All Billing Information
        [HttpGet]
        public IActionResult GetBillingInfo()
        {
            var billingInfo = _context.Payments.ToList();
            return Ok(billingInfo);
        }

        // Process a Payment (Duplicate of SubmitPayment for compatibility)
        [HttpPost("makePayment")]
        public IActionResult MakePayment([FromBody] Payment payment)
        {
            if (payment == null || !ModelState.IsValid)
            {
                return BadRequest(new { message = "Invalid payment data." });
            }

            _context.Payments.Add(payment);
            _context.SaveChanges();
            return Ok(new { message = "Payment processed successfully." });
        }
    }
}
