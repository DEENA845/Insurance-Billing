﻿using demo1.Data;
using demo1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace demo1.Controllers
{
    [ApiController]
    [Route("api/policies")]
    public class PoliciesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PoliciesController(AppDbContext context)
        {
            _context = context;
        }

        // Generate PolicyId for the form
        [HttpGet("generatePolicyId")]
        public IActionResult GeneratePolicyId()
        {
            // Generate a unique PolicyId
            string yearPrefix = DateTime.Now.ToString("yy");
            string monthPrefix = DateTime.Now.ToString("MM");
            string policyPrefix = "IBS";
            string uniqueSuffix;

            do
            {
                uniqueSuffix = new Random().Next(10000, 99999).ToString(); // Generate 5-digit unique suffix
            } while (_context.Policies.Any(p => p.PolicyId == $"{yearPrefix}{monthPrefix}{policyPrefix}{uniqueSuffix}"));

            string generatedPolicyId = $"{yearPrefix}{monthPrefix}{policyPrefix}{uniqueSuffix}";
            return Ok(generatedPolicyId);
        }

        // Fetch policy names based on policy type
        [HttpGet("getPolicyNames")]
        public IActionResult GetPolicyNames(string type)
        {
            var policyNames = _context.Policies
                .Where(p => p.Type == type)
                .Select(p => p.PolicyName)
                .Distinct()
                .ToList();

            return Ok(new { policyNames });
        }

        // Handle form submissions for policies
        [HttpPost("addPolicy")]
        public IActionResult AddPolicy([FromForm] Policy policy)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (_context.Policies.Any(p => p.PolicyId == policy.PolicyId))
            {
                return Conflict(new { message = "PolicyId already exists." });
            }

            // Save the new policy
            _context.Policies.Add(policy);
            _context.SaveChanges();

            return Ok(new { message = "Policy added successfully." });
        }
    }
}
