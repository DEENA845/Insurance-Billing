﻿using Microsoft.AspNetCore.Mvc;
using demo1.Models;
using demo1.Data; // Assuming your DbContext is in this namespace
using System.Linq;

namespace demo1.AdminControllers
{
    [Route("admin/claims")]
    public class AdminClaimsController : Controller
    {
        private readonly AppDbContext _context;

        public AdminClaimsController(AppDbContext context)
        {
            _context = context;
        }

        // Display claim management view
        [HttpGet("manage")]
        public IActionResult ManageClaims()
        {
            var claims = _context.Claims.ToList();
            return View(claims);
        }

        // Approve a specific claim
        [HttpPost("approve")]
        public IActionResult ApproveClaim(int claimId)
        {
            var claim = _context.Claims.Find(claimId);
            if (claim == null)
            {
                return NotFound(new { message = "Claim not found." });
            }

            claim.ClaimStatus = "Approved";
            _context.SaveChanges();

            return Ok(new { message = $"Claim {claimId} approved successfully." });
        }

        // Reject a specific claim
        [HttpPost("reject")]
        public IActionResult RejectClaim(int claimId)
        {
            var claim = _context.Claims.Find(claimId);
            if (claim == null)
            {
                return NotFound(new { message = "Claim not found." });
            }

            claim.ClaimStatus = "Rejected";
            _context.SaveChanges();

            return Ok(new { message = $"Claim {claimId} rejected successfully." });
        }
    }
}
