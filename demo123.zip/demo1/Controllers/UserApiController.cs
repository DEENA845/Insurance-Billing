﻿using Microsoft.AspNetCore.Mvc;
using demo1.Data;
using demo1.Models;
using System.Linq;

namespace demo1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserApiController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UserApiController(AppDbContext context)
        {
            _context = context;
        }

        // Get all users
        [HttpGet]
        public IActionResult GetUsers()
        {
            try
            {
                var users = _context.Users.Select(u => new
                {
                    u.Id,
                    u.Name,
                    u.Email
                }).ToList();
                return Ok(users); // Return users in JSON format
            }
            catch
            {
                return StatusCode(500, "An error occurred while fetching users.");
            }
        }

        // Add a new user
        [HttpPost]
        public IActionResult AddUser([FromBody] User user)
        {
            if (user == null || !ModelState.IsValid)
            {
                return BadRequest(new { message = "Invalid user data." });
            }

            try
            {
                _context.Users.Add(user);
                _context.SaveChanges();
                return Ok(new { message = "User added successfully." });
            }
            catch
            {
                return StatusCode(500, "An error occurred while adding the user.");
            }
        }
    }
}


