﻿using demo1.Data;
using demo1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Linq;

namespace demo1.Controllers
{
    public class LoginController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly AppDbContext _context;

        public LoginController(IConfiguration configuration, AppDbContext context)
        {
            _configuration = configuration;
            _context = context;
        }

        // Return the User Login View
        [HttpGet]
        public IActionResult UserLogin()
        {
            return View();
        }

        // Return the Register View
        [HttpGet]
        [Route("User/Register")]
        public IActionResult Register()
        {
            return View();
        }

        // Return the Admin Login View
        [HttpGet]
        public IActionResult AdminLogin()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Dashboard(User user)
        {
            return View(user);
        }


        [HttpPost]
        [Route("validate")] // Route: api/user/validate
        public IActionResult ValidateUser(string username, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == username);

            if (user != null && user.Password == password)
            {
                Console.WriteLine("User found: " + user.Name);
                return RedirectToAction("Dashboard", new { user });
            }

            ViewBag.ErrorMessage = "Invalid username or password.";
            return View("UserLogin");
        }

        // Validate Admin Login
        [HttpPost]
        public IActionResult ValidateAdmin(string username, string password)
        {
            var adminUsername = _configuration["AdminCredentials:AdminUsername"];
            var adminPassword = _configuration["AdminCredentials:AdminPassword"];

            if (username == adminUsername && password == adminPassword)
            {
                return RedirectToAction("Dashboard", "Admin");
            }

            ViewBag.ErrorMessage = "Invalid username or password.";
            return View("AdminLogin");
        }

        // Register User
        [HttpPost]
        public IActionResult RegisterUser(User model)
        {
            if (ModelState.IsValid)
            {
                _context.Users.Add(model);
                _context.SaveChanges();
                return RedirectToAction("UserLogin");
            }
            return View("Register", model);
        }
    }
}
