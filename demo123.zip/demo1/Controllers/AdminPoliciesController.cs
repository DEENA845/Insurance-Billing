﻿using Microsoft.AspNetCore.Mvc;
using demo1.Models;
using demo1.Data; // Assuming your DbContext is in this namespace
using System.Linq;

namespace demo1.AdminControllers
{
    [Route("admin/policies")]
    public class AdminPoliciesController : Controller
    {
        private readonly AppDbContext _context;

        public AdminPoliciesController(AppDbContext context)
        {
            _context = context;
        }

        // Display policy management view
        [HttpGet("manage")]
        public IActionResult ManagePolicies()
        {
            var policies = _context.Policies.ToList();
            return View(policies);
        }

        // Add a new policy
        [HttpPost("add")]
        public IActionResult AddPolicy(Policy policy)
        {
            if (ModelState.IsValid)
            {
                _context.Policies.Add(policy);
                _context.SaveChanges();
                return Ok(new { message = $"Policy '{policy.PolicyName}' added successfully." });
            }
            return BadRequest(ModelState);
        }

        // Edit an existing policy
        [HttpPost("edit")]
        public IActionResult EditPolicy(int policyId, Policy updatedPolicy)
        {
            var policy = _context.Policies.Find(policyId);
            if (policy == null)
            {
                return NotFound(new { message = "Policy not found." });
            }

            if (ModelState.IsValid)
            {
                policy.PolicyName = updatedPolicy.PolicyName;
                policy.CoverageAmount = updatedPolicy.CoverageAmount;
                policy.Premium = updatedPolicy.Premium;
                _context.SaveChanges();
                return Ok(new { message = $"Policy {policyId} updated successfully." });
            }
            return BadRequest(ModelState);
        }
    }
}
