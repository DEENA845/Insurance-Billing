﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using demo1.Data;
using demo1.Models;

namespace demo1.Controllers
{
    [Route("api/claims")]
    [ApiController]
    public class ClaimsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ClaimsController(AppDbContext context)
        {
            _context = context;
        }

        // Fetch Policy and User Details by Policy ID for Claim Processing
        [HttpGet("getPolicyAndUserDetails")]
        public IActionResult GetPolicyAndUserDetails(string policyId)
        {
            if (string.IsNullOrWhiteSpace(policyId))
                return BadRequest(new { message = "Policy ID is required." });

            var policy = _context.Policies.FirstOrDefault(p => p.PolicyId == policyId);
            if (policy == null)
                return NotFound(new { message = "Policy not found." });

            var user = _context.Users.FirstOrDefault(u => u.Id == policy.Id);
            if (user == null)
                return NotFound(new { message = "User associated with this policy not found." });

            return Ok(new
            {
                PolicyId = policy.PolicyId,
                PolicyName = policy.Name,
                PolicyholderName = user.Name,
                ContactInformation = user.Phone
            });
        }

        // Submit a New Claim
        [HttpPost("submitClaim")]
        public async Task<IActionResult> SubmitClaim([FromBody] Claim claim)
        {
            if (claim == null || !ModelState.IsValid)
                return BadRequest(new { message = "Invalid claim data." });

            var policy = _context.Policies.FirstOrDefault(p => p.Id == claim.PolicyId);
            if (policy == null)
                return NotFound(new { message = "Invalid Policy ID." });

            try
            {
                await _context.Claims.AddAsync(claim);
                await _context.SaveChangesAsync();
                return Ok(new { message = "Claim submitted successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while submitting the claim.", error = ex.Message });
            }
        }
    }
}
