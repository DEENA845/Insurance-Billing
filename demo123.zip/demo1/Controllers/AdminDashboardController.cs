﻿using Microsoft.AspNetCore.Mvc;
using demo1.Models;
using demo1.Data; // Assuming your DbContext is in this namespace
using System.Linq;

namespace demo1.AdminControllers
{
    [Route("admin/dashboard")]
    public class AdminDashboardController : Controller
    {
        private readonly AppDbContext _context;

        public AdminDashboardController(AppDbContext context)
        {
            _context = context;
        }

        // Display the admin dashboard with widgets and charts
        [HttpGet]
        public IActionResult Index()
        {
            // Fetch necessary data for widgets (e.g., claim stats, user count)
            var dashboardData = new AdminDashboardData
            {
                TotalUsers = _context.Users.Count(),
                ActiveClaims = _context.Claims.Count(c => c.Status == "Active"),
                PendingPayments = _context.Payments.Count(p => p.Status == "Pending")
            };

            return View(dashboardData);
        }

        // Endpoint to fetch chart data for claims
        [HttpGet("chart-data")]
        public IActionResult GetChartData()
        {
            var data = new List<AdminChartData>
            {
                new AdminChartData { Label = "Approved Claims", Value = _context.Claims.Count(c => c.Status == "Approved") },
                new AdminChartData { Label = "Rejected Claims", Value = _context.Claims.Count(c => c.Status == "Rejected") },
                new AdminChartData { Label = "Pending Claims", Value = _context.Claims.Count(c => c.Status == "Pending") }
            };

            return Json(new
            {
                labels = data.Select(d => d.Label).ToArray(),
                values = data.Select(d => d.Value).ToArray()
            });
        }
    }
}
