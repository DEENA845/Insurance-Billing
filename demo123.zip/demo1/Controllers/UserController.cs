﻿using demo1.Data;
using demo1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace demo1.Controllers
{
    [ApiController]
    [Route("api/user")] // Base route for the controller
    public class UserController : Controller
    {
        private readonly AppDbContext _context;

        public UserController(AppDbContext context)
        {
            _context = context;
        }

        // Return the Register View
        [HttpGet]
        [Route("register")] // Route: api/user/register
        public IActionResult Register()
        {
            return View("~/Views/Login/Register.cshtml"); // Explicitly specify the custom path
        }

        // Register a new user
        [HttpPost]
        [Route("register")] // Route: api/user/register
        public IActionResult RegisterUser([FromForm] User user)
        {
            if (ModelState.IsValid)
            {
                var existingUser = _context.Users.FirstOrDefault(u => u.Email == user.Email);
                if (existingUser != null)
                {
                    return Conflict(new { message = "Email already registered." });
                }

                // Set default profile picture if not provided
                if (string.IsNullOrEmpty(user.ProfilePictureUrl))
                {
                    user.ProfilePictureUrl = user.Gender.ToLower() == "male" ? "/images/default-male.png" : "/images/default-female.png";
                }

                _context.Users.Add(user);
                _context.SaveChanges();
                return RedirectToAction("UserLogin", "Login");
            }
            return View("Register", user);
        }

        // Validate User Login
        [HttpPost]
        [Route("validate")] // Route: api/user/validate
        public IActionResult ValidateUser(string username, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == username);

            if (user != null && user.Password == password)
            {
                Console.WriteLine("User found: " + user.Name);
                return RedirectToAction("Dashboard", "User");
            }

            ViewBag.ErrorMessage = "Invalid username or password.";
            return View("UserLogin");
        }

        // Reset password - Send reset link
        [HttpPost]
        [Route("reset-password")] // Route: api/user/reset-password
        public IActionResult SendPasswordResetLink(ResetPasswordRequest model)
        {
            if (string.IsNullOrWhiteSpace(model.Email))
            {
                return BadRequest(new { success = false, message = "Invalid email address." });
            }

            var user = _context.Users.FirstOrDefault(u => u.Email == model.Email);

            if (user != null)
            {
                // Logic for sending reset password link goes here
                return Ok(new { success = true, message = "Password reset link sent." });
            }

            return NotFound(new { success = false, message = "Email not found." });
        }

        // Dashboard View
        [HttpGet]
        [Route("dashboard")] // Route: api/user/dashboard
        public IActionResult Dashboard()
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == User.Identity.Name);
            if (user == null)
            {
                return NotFound(new { success = false, message = "User not found." });
            }

            // Set default profile picture if not provided
            if (string.IsNullOrEmpty(user.ProfilePictureUrl))
            {
                user.ProfilePictureUrl = user.Gender.ToLower() == "male" ? "/images/default-male.png" : "/images/default-female.png";
            }

            return View(user); // Ensure the corresponding view exists in Views/User/Dashboard.cshtml
        }

        // Profile Popup Content
        [HttpGet("profile")]
        public IActionResult GetProfileContent()
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == User.Identity.Name);
            if (user == null)
            {
                return NotFound(new { success = false, message = "User not found." });
            }

            // Set default profile picture if not provided
            if (string.IsNullOrEmpty(user.ProfilePictureUrl))
            {
                user.ProfilePictureUrl = user.Gender.ToLower() == "male" ? "/images/default-male.png" : "/images/default-female.png";
            }

            return PartialView("_ProfilePartial", user);
        }

        // Handle form submissions for profile updates
        [HttpPost("profile")]
        public IActionResult UpdateProfile(User user)
        {
            if (ModelState.IsValid)
            {
                var existingUser = _context.Users.FirstOrDefault(u => u.Id == user.Id);
                if (existingUser != null)
                {
                    existingUser.Name = user.Name;
                    existingUser.Email = user.Email;
                    existingUser.Phone = user.Phone;
                    existingUser.Address = user.Address;
                    existingUser.ProfilePictureUrl = user.ProfilePictureUrl;
                    existingUser.DateOfBirth = user.DateOfBirth;

                    _context.SaveChanges();
                    return Ok(new { success = true, message = "Profile updated successfully." });
                }
                return NotFound(new { success = false, message = "User not found." });
            }
            return BadRequest(new { success = false, message = "Invalid data." });
        }

        // Policy Popup Content
        [HttpGet("policy")]
        public IActionResult GetPolicyContent()
        {
            var policies = _context.Policies.ToList();
            if (policies == null || !policies.Any())
            {
                policies = new List<Policy>();
            }
            return PartialView("_PolicyPartial", policies);
        }



        [HttpGet("generatePolicyId")]
        public IActionResult GeneratePolicyId()
        {
            // Generate a unique PolicyId
            string yearPrefix = DateTime.Now.ToString("yy");
            string monthPrefix = DateTime.Now.ToString("MM");
            string policyPrefix = "IBS";
            string uniqueSuffix;

            do
            {
                uniqueSuffix = new Random().Next(10000, 99999).ToString(); // Generate 5-digit unique suffix
            } while (_context.Policies.Any(p => p.PolicyId == $"{yearPrefix}{monthPrefix}{policyPrefix}{uniqueSuffix}"));

            string generatedPolicyId = $"{yearPrefix}{monthPrefix}{policyPrefix}{uniqueSuffix}";
            return Ok(generatedPolicyId);
        }

        // Handle form submissions for policies
        [HttpPost("policy")]
        public IActionResult AddPolicy([FromForm] Policy policy)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (_context.Policies.Any(p => p.PolicyId == policy.PolicyId))
            {
                return Conflict(new { message = "PolicyId already exists." });
            }

            // Save the new policy
            _context.Policies.Add(policy);
            _context.SaveChanges();

            return Ok(new { message = "Policy added successfully." });
        }


        // Claims Popup Content
        [HttpGet("claims")]
        public IActionResult GetClaimsContent()
        {
            var claims = _context.Claims.ToList();
            if (claims == null)
            {
                claims = new List<Claim>();
            }
            return PartialView("_ClaimsPartial", claims);
        }

        // Handle form submissions for claims
        [HttpPost("claims")]
        public IActionResult SubmitClaim(Claim claim)
        {
            if (ModelState.IsValid)
            {
                _context.Claims.Add(claim);
                _context.SaveChanges();
                return Ok(new { success = true, message = "Claim submitted successfully." });
            }
            return BadRequest(new { success = false, message = "Invalid data." });
        }

        // Billing Popup Content
        [HttpGet("billing")]
        public IActionResult GetBillingContent()
        {
            var payments = _context.Payments.ToList();
            if (payments == null || !payments.Any())
            {
                payments = new List<Payment>();
            }
            return PartialView("_BillingPartial", payments);
        }

        // Handle form submissions for billing
        [HttpPost("billing")]
        public IActionResult MakePayment(Payment payment)
        {
            if (ModelState.IsValid)
            {
                _context.Payments.Add(payment);
                _context.SaveChanges();
                return Ok(new { success = true, message = "Payment made successfully." });
            }
            return BadRequest(new { success = false, message = "Invalid data." });
        }

        // Documents Popup Content
        [HttpGet("documents")]
        public IActionResult GetDocumentsContent()
        {
            var documents = _context.Documents.ToList();
            if (documents == null || !documents.Any())
            {
                documents = new List<Document>();
            }
            return PartialView("_DocumentsPartial", documents);
        }

        // Handle form submissions for documents
        [HttpPost("documents")]
        public IActionResult UploadDocument(Document document)
        {
            if (ModelState.IsValid)
            {
                _context.Documents.Add(document);
                _context.SaveChanges();
                return Ok(new { success = true, message = "Document uploaded successfully." });
            }
            return BadRequest(new { success = false, message = "Invalid data." });
        }
    }
}
