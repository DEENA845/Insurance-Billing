﻿    using Microsoft.AspNetCore.Mvc;

    namespace demo1.Controllers
    {
        [ApiController]
        [Route("api/user-popup")] // Base route for the controller
        public class UserPopupController : Controller
        {
            // Dashboard Popup Content
            [HttpGet("dashboard")]
            public IActionResult GetDashboardContent()
            {
                return Content("<h3>Dashboard Content</h3><p>Welcome to your dashboard!</p>", "text/html");
            }

            // Profile Popup Content
            [HttpGet("profile")]
            public IActionResult GetProfileContent()
            {
                return Content("<h3>Profile Content</h3><p>Your profile details will be shown here.</p>", "text/html");
            }

            // Policy Popup Content
            [HttpGet("policy")]
            public IActionResult GetPolicyContent()
            {
                return Content("<h3>Policy Details Content</h3><p>Your active insurance policies will be listed here.</p>", "text/html");
            }

            // Claims Popup Content
            [HttpGet("claims")]
            public IActionResult GetClaimsContent()
            {
                return Content("<h3>Claims Content</h3><p>Submit and manage your claims here.</p>", "text/html");
            }

            // Billing Popup Content
            [HttpGet("billing")]
            public IActionResult GetBillingContent()
            {
                return Content("<h3>Billing Content</h3><p>Manage your payment history and billing details.</p>", "text/html");
            }

            // Documents Popup Content
            [HttpGet("documents")]
            public IActionResult GetDocumentsContent()
            {
                return Content("<h3>Documents Content</h3><p>Upload and download your insurance documents.</p>", "text/html");
            }
        }
    }
